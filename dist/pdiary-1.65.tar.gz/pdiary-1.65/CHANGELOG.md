## Changelog
All notable changes to this project will be documented in this file.

### v1.65 2022-08-08
- Fixed issues reported in the Github page and others bugs
- Added support to export entries to txt files
- Fixed some bugs in the lines of the screen
- Password is optional now
- Implemented Welcome Screen with options
- Implemented Settings session
- Search function implemented
- Themes Support

### v0.80 2018-08-11
- First release
